"""
Parsing e incorporação dos dados mensais do CERT.br (de 2016 até 2025).
Três séries temporais mensais:
- total_incidentes: total de incidentes notificados
- fraude: total da categoria Fraude (phishing e malware)
- phishing: phishing especificamente (subdivisão da Fraude)
Saída: /home/artigos/ajustar/ipea/analise/outputs/serie_mensal.csv

"""

import os
import re
import pandas as pd
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data" / "raw"
OUT_DIR = BASE_DIR / "data"
OUT_DIR.mkdir(parents=True, exist_ok=True)

ANOS = range(2016, 2027)  # 2016 até 2026 (parcial)

def parse_incidentes_mensal(path):
    """Parsea arquivo NNNN_incidentes-mensal.txt: total mensal de incidentes."""
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            # Formato: MM  num  %
            if len(parts) >= 3 and parts[0].isdigit() and len(parts[0]) == 2:
                mes = int(parts[0])
                num = int(parts[1])
                rows.append({"mes": mes, "total_incidentes": num})
    return pd.DataFrame(rows)

def parse_tipos_incidente_mensal(path):
    """Parsea NNNN_tipos-incidente-mensal.txt: incidentes por categoria por mês.
    
    Cabeçalho:
    # Mês  Total  DoS  %  Fraude  %  Invasão  %  Outros  %  Scan  %  Web  %
    """
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("Total"):
                continue
            parts = line.split()
            # Linha mensal: MM Total DoS % Fraude % Invasão % Outros % Scan % Web %
            if len(parts) >= 13 and parts[0].isdigit() and len(parts[0]) == 2:
                mes = int(parts[0])
                total = int(parts[1])
                dos = int(parts[2])
                fraude = int(parts[4])
                invasao = int(parts[6])
                outros = int(parts[8])
                scan = int(parts[10])
                web = int(parts[12])
                rows.append({
                    "mes": mes,
                    "total": total,
                    "dos": dos,
                    "fraude": fraude,
                    "invasao": invasao,
                    "outros": outros,
                    "scan": scan,
                    "web": web,
                })
    return pd.DataFrame(rows)

def parse_tipos_fraude_mensal(path):
    """Parsea NNNN_tipos-fraude-mensal.txt: phishing e malware por mês.
    
    Cabeçalho:
    # Mês  Total  malware  %  phishing  %
    """
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("Total"):
                continue
            parts = line.split()
            # Linha mensal: MM Total malware % phishing %
            if len(parts) >= 6 and parts[0].isdigit() and len(parts[0]) == 2:
                mes = int(parts[0])
                total_fraude = int(parts[1])
                malware = int(parts[2])
                phishing = int(parts[4])
                rows.append({
                    "mes": mes,
                    "total_fraude": total_fraude,
                    "malware": malware,
                    "phishing": phishing,
                })
    return pd.DataFrame(rows)


# Consolidar todos os anos em uma série única
todas_linhas = []

for ano in ANOS:
    f_inc = DATA_DIR / f"{ano}_incidentes-mensal.txt"
    f_tip = DATA_DIR / f"{ano}_tipos-incidente-mensal.txt"
    f_fra = DATA_DIR / f"{ano}_tipos-fraude-mensal.txt"
    
    if not f_inc.exists():
        continue
    
    df_inc = parse_incidentes_mensal(f_inc)
    df_tip = parse_tipos_incidente_mensal(f_tip)
    df_fra = parse_tipos_fraude_mensal(f_fra)
    
    # Merge pelo mês
    df = df_inc.merge(df_tip, on="mes", how="outer", suffixes=("", "_tip"))
    df = df.merge(df_fra, on="mes", how="outer")
    df["ano"] = ano
    
    todas_linhas.append(df)

serie = pd.concat(todas_linhas, ignore_index=True)
serie["data"] = pd.to_datetime(
    serie[["ano", "mes"]].rename(columns={"ano": "year", "mes": "month"}).assign(day=1)
)
serie = serie.sort_values("data").reset_index(drop=True)

# Reorganizar colunas
serie = serie[["data", "ano", "mes", "total_incidentes", 
               "dos", "fraude", "invasao", "outros", "scan", "web",
               "malware", "phishing"]]

# Salvar
out_path = OUT_DIR / "serie_mensal.csv"
serie.to_csv(out_path, index=False)

print(f"Arquivo salvo: {out_path}")
print(f"Observações: {len(serie)}")
print(f"Período: {serie['data'].min()} a {serie['data'].max()}")
print()
print("Resumo anual (totais):")
print(serie.groupby("ano")[["total_incidentes", "fraude", "phishing", "malware"]].sum().to_string())
print()
print("Primeiras linhas:")
print(serie.head(6).to_string())
print()
print("Últimas linhas:")
print(serie.tail(6).to_string())
