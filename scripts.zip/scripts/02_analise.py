"""
Construção de tabela e análise empírica da série mensal de phishing CERT.br (de 2016 até 2025).

1. Estatísticas descritivas
2. Decomposição STL (Cleveland et al. 1990)
3. Quebras estruturais (Bai-Perron via ruptures)
4. Regressão OLS log-linear com dummies sazonais e eventos
5. Gráficos publicáveis no padrão da PPE (alta resolução, escala de cinza)

Saídas em /home/artigos/ajustar/ipea/analise/outputs/ e /figuras/

"""

import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from pathlib import Path

from statsmodels.tsa.seasonal import STL
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_hac
import ruptures as rpt

BASE_DIR = Path(__file__).resolve().parent.parent
OUT = BASE_DIR / "outputs"
FIG = BASE_DIR / "figuras"
OUT.mkdir(parents=True, exist_ok=True)
FIG.mkdir(parents=True, exist_ok=True)

# ============================================================
# 1. CARGA E PREPARAÇÃO
# ============================================================

df = pd.read_csv(BASE_DIR / "data" / "serie_mensal.csv")
df["data"] = pd.to_datetime(df["data"])
# Recorte: usar até 2025-12 (10 anos completos = 120 obs)
df = df[df["data"] < "2026-01-01"].copy().reset_index(drop=True)
df = df.set_index("data")

print(f"Série: {df.index.min().strftime('%Y-%m')} a {df.index.max().strftime('%Y-%m')}")
print(f"Observações: {len(df)}")

# Variáveis principais
y = df["phishing"].astype(float)
y_log = np.log(y)
fraude = df["fraude"].astype(float)
total = df["total_incidentes"].astype(float)
share = (y / total * 100)  # % do total de incidentes

# ============================================================
# 2. ESTATÍSTICAS DESCRITIVAS
# ============================================================

print("\n=== ESTATÍSTICAS DESCRITIVAS ===")
desc_anual = df.groupby("ano").agg(
    phishing_total=("phishing", "sum"),
    phishing_media=("phishing", "mean"),
    phishing_dp=("phishing", "std"),
    phishing_min=("phishing", "min"),
    phishing_max=("phishing", "max"),
    total_incidentes=("total_incidentes", "sum"),
)
desc_anual["share_phishing_%"] = desc_anual["phishing_total"] / desc_anual["total_incidentes"] * 100
desc_anual["cv"] = desc_anual["phishing_dp"] / desc_anual["phishing_media"]
print(desc_anual.round(2).to_string())
desc_anual.to_csv(OUT / "tabela1_descritivas_anuais.csv")

# Taxa de crescimento mensal e anual (CAGR)
cagr = (y.iloc[-1] / y.iloc[0]) ** (1/((len(y)-1)/12)) - 1
print(f"\nCAGR (taxa anual composta) janeiro/2016 a dezembro/2025: {cagr*100:.2f}%")

# ============================================================
# 3. DECOMPOSIÇÃO STL (Cleveland et al. 1990)
# ============================================================

print("\n=== DECOMPOSIÇÃO STL ===")
stl = STL(y_log, period=12, seasonal=13, robust=True)
res = stl.fit()

# Tabela: coeficientes sazonais médios por mês (em logs e em % desvio da tendência)
seasonal_by_month = res.seasonal.groupby(res.seasonal.index.month).mean()
# Converter de log para % (e^x - 1)
seasonal_pct = (np.exp(seasonal_by_month) - 1) * 100
tab_sazonal = pd.DataFrame({
    "mes": ["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"],
    "coef_log": seasonal_by_month.values,
    "desvio_%": seasonal_pct.values
})
print(tab_sazonal.round(3).to_string(index=False))
tab_sazonal.to_csv(OUT / "tabela2_componente_sazonal.csv", index=False)

# ============================================================
# 4. QUEBRAS ESTRUTURAIS (Bai-Perron via ruptures)
# ============================================================

print("\n=== QUEBRAS ESTRUTURAIS ===")
# Algoritmo PELT com modelo de mudança de média e penalty BIC-like
signal = y_log.values.reshape(-1, 1)
# Bai-Perron clássico: modelo l2 (mudança de nível), penalty calibrado
algo = rpt.Pelt(model="l2", min_size=8).fit(signal)
# Tentamos diferentes pen e selecionamos via BIC
n = len(signal)
sigma2 = np.var(signal)
# Pen BIC = sigma2 * log(n)
pen_bic = sigma2 * np.log(n) * 3
breaks = algo.predict(pen=pen_bic)
breaks_idx = [b for b in breaks if b < n]
break_dates = [y_log.index[b].strftime("%Y-%m") for b in breaks_idx]
print(f"Quebras detectadas (PELT, pen=BIC): {break_dates}")

# Estatísticas por segmento
segments = []
prev = 0
for b in breaks_idx + [n]:
    seg = y_log.iloc[prev:b]
    seg_real = y.iloc[prev:b]
    segments.append({
        "inicio": seg.index[0].strftime("%Y-%m"),
        "fim": seg.index[-1].strftime("%Y-%m"),
        "n_meses": len(seg),
        "media_log": seg.mean(),
        "media_real": seg_real.mean(),
        "dp_real": seg_real.std()
    })
    prev = b
df_seg = pd.DataFrame(segments)
print(df_seg.round(2).to_string(index=False))
df_seg.to_csv(OUT / "tabela3_quebras_estruturais.csv", index=False)

# ============================================================
# 5. REGRESSÃO OLS LOG-LINEAR COM DUMMIES SAZONAIS E EVENTOS
# ============================================================

print("\n=== REGRESSÃO OLS LOG-LINEAR ===")

reg_df = pd.DataFrame(index=y_log.index)
reg_df["log_phishing"] = y_log.values
reg_df["t"] = np.arange(len(reg_df))  # tendência linear

# Dummies sazonais (mês 1 = janeiro como base, omite Dezembro como referência)
for m in range(1, 12):  # 1..11, mantém Dezembro (12) como referência
    reg_df[f"m{m}"] = (reg_df.index.month == m).astype(int)

# Dummies de eventos estruturais (calibradas por achados teóricos do artigo)
reg_df["pandemia"] = ((reg_df.index >= "2020-03-01") & (reg_df.index <= "2021-12-31")).astype(int)
reg_df["pos_pix"] = (reg_df.index >= "2020-11-01").astype(int)
reg_df["eleicao_2022"] = ((reg_df.index >= "2022-08-01") & (reg_df.index <= "2022-10-31")).astype(int)
reg_df["era_ia"] = (reg_df.index >= "2024-01-01").astype(int)

# Estimação OLS
X = sm.add_constant(reg_df.drop(columns=["log_phishing"]))
y_reg = reg_df["log_phishing"]
modelo = sm.OLS(y_reg, X).fit(cov_type="HAC", cov_kwds={"maxlags": 12})
print(modelo.summary())

# Salvar tabela com coeficientes
out_reg = pd.DataFrame({
    "variavel": modelo.params.index,
    "coef": modelo.params.values,
    "ep_hac": modelo.bse.values,
    "t": modelo.tvalues.values,
    "p_valor": modelo.pvalues.values,
    "ic_inf_95": modelo.conf_int()[0].values,
    "ic_sup_95": modelo.conf_int()[1].values
})
out_reg.to_csv(OUT / "tabela4_regressao.csv", index=False)
print("\nR² ajustado:", modelo.rsquared_adj)
print("F-stat:", modelo.fvalue, "p:", modelo.f_pvalue)

# Interpretação dos coeficientes mensais (em % de desvio em relação a Dezembro)
print("\n=== EFEITO SAZONAL ESTIMADO (% desvio vs Dezembro, controlando por tendência e eventos) ===")
nomes_meses = {1:"Jan",2:"Fev",3:"Mar",4:"Abr",5:"Mai",6:"Jun",
               7:"Jul",8:"Ago",9:"Set",10:"Out",11:"Nov"}
efeitos = []
for m in range(1, 12):
    coef = modelo.params[f"m{m}"]
    pval = modelo.pvalues[f"m{m}"]
    pct = (np.exp(coef) - 1) * 100
    sig = "***" if pval<0.01 else ("**" if pval<0.05 else ("*" if pval<0.10 else ""))
    efeitos.append({"mes": nomes_meses[m], "coef": coef, "desvio_%": pct, "p": pval, "sig": sig})
    print(f"  {nomes_meses[m]}: {pct:+.2f}% (p={pval:.3f}) {sig}")
pd.DataFrame(efeitos).to_csv(OUT / "tabela5_efeitos_sazonais.csv", index=False)

# Interpretação dos eventos
print("\n=== EFEITO DOS EVENTOS ESTRUTURAIS ===")
for ev in ["pandemia", "pos_pix", "eleicao_2022", "era_ia"]:
    coef = modelo.params[ev]
    pval = modelo.pvalues[ev]
    pct = (np.exp(coef) - 1) * 100
    sig = "***" if pval<0.01 else ("**" if pval<0.05 else ("*" if pval<0.10 else ""))
    print(f"  {ev}: {pct:+.2f}% (p={pval:.3f}) {sig}")

# Coeficiente de tendência
t_coef = modelo.params["t"]
t_pct_mes = (np.exp(t_coef) - 1) * 100
t_pct_ano = (np.exp(t_coef*12) - 1) * 100
print(f"\nTendência: {t_pct_mes:+.3f}% ao mês ({t_pct_ano:+.2f}% ao ano)")

# ============================================================
# 6. GRÁFICOS PUBLICÁVEIS
# ============================================================

print("\n=== GERANDO FIGURAS ===")

# Configuração geral - estilo PPE (acadêmico, escala de cinza opcional)
plt.rcParams.update({
    "font.family": "DejaVu Serif",
    "font.size": 10,
    "axes.titlesize": 11,
    "axes.labelsize": 10,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "grid.alpha": 0.3,
    "grid.linewidth": 0.5,
    "figure.dpi": 130,
})

# Figura 1: Série temporal completa com eventos
fig, ax = plt.subplots(figsize=(11, 4.5))
ax.plot(y.index, y.values, color="#1f3a5f", linewidth=1.4)
ax.set_xlabel("")
ax.set_ylabel("Notificações de phishing (mensais)")
ax.set_title("Figura 1. Série mensal de notificações de phishing ao CERT.br (2016–2025)", loc="left")

# Anotações de eventos
events = [
    ("2020-03-01", "Início da\npandemia"),
    ("2020-11-01", "Lançamento\ndo Pix"),
    ("2022-10-01", "Eleições\n2022"),
    ("2024-01-01", "Era IA\ngenerativa"),
]
for date, label in events:
    d = pd.Timestamp(date)
    ax.axvline(d, color="gray", linestyle="--", linewidth=0.8, alpha=0.7)
    ax.text(d, ax.get_ylim()[1]*0.95, label, fontsize=8, ha="left", va="top",
            rotation=0, color="dimgray")

# Marca quebras estruturais detectadas
for b in breaks_idx:
    d = y.index[b]
    ax.axvline(d, color="firebrick", linestyle=":", linewidth=1.0, alpha=0.85)

ax.xaxis.set_major_locator(mdates.YearLocator())
ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
ax.set_xlim(y.index.min() - pd.Timedelta(days=15), y.index.max() + pd.Timedelta(days=15))
plt.tight_layout()
plt.savefig(FIG / "fig1_serie_temporal.png", dpi=300, bbox_inches="tight")
plt.savefig(FIG / "fig1_serie_temporal.pdf", bbox_inches="tight")
plt.close()
print("  fig1_serie_temporal.png/pdf")

# Figura 2: Decomposição STL
fig, axes = plt.subplots(4, 1, figsize=(11, 9), sharex=True)
axes[0].plot(y_log.index, y_log.values, color="#1f3a5f", linewidth=1.2)
axes[0].set_ylabel("Observada\n(log)")
axes[0].set_title("Figura 2. Decomposição STL da série mensal de phishing (em logs)", loc="left")

axes[1].plot(res.trend.index, res.trend.values, color="#2d5a3d", linewidth=1.5)
axes[1].set_ylabel("Tendência")

axes[2].plot(res.seasonal.index, res.seasonal.values, color="#704214", linewidth=1.0)
axes[2].set_ylabel("Sazonal")
axes[2].axhline(0, color="black", linewidth=0.5)

axes[3].plot(res.resid.index, res.resid.values, color="#666666", linewidth=0.8)
axes[3].set_ylabel("Resíduo")
axes[3].axhline(0, color="black", linewidth=0.5)
axes[3].xaxis.set_major_locator(mdates.YearLocator())
axes[3].xaxis.set_major_formatter(mdates.DateFormatter("%Y"))

plt.tight_layout()
plt.savefig(FIG / "fig2_stl.png", dpi=300, bbox_inches="tight")
plt.savefig(FIG / "fig2_stl.pdf", bbox_inches="tight")
plt.close()
print("  fig2_stl.png/pdf")

# Figura 3: Componente sazonal médio mensal
fig, ax = plt.subplots(figsize=(8, 4.5))
meses_label = ["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"]
colors = ["#2d5a3d" if v >= 0 else "#8B0000" for v in seasonal_pct.values]
ax.bar(meses_label, seasonal_pct.values, color=colors, edgecolor="black", linewidth=0.5)
ax.axhline(0, color="black", linewidth=0.7)
ax.set_ylabel("Desvio sazonal (% vs tendência)")
ax.set_title("Figura 3. Componente sazonal médio das notificações de phishing", loc="left")
for i, v in enumerate(seasonal_pct.values):
    ax.text(i, v + (1.5 if v>=0 else -3), f"{v:+.1f}%", ha="center", fontsize=8.5)
plt.tight_layout()
plt.savefig(FIG / "fig3_sazonal_medio.png", dpi=300, bbox_inches="tight")
plt.savefig(FIG / "fig3_sazonal_medio.pdf", bbox_inches="tight")
plt.close()
print("  fig3_sazonal_medio.png/pdf")

# Figura 4: Heatmap mensal (ano × mês)
heatmap_data = df.pivot_table(values="phishing", index="ano", columns="mes", aggfunc="sum")
fig, ax = plt.subplots(figsize=(10, 5))
im = ax.imshow(heatmap_data.values, aspect="auto", cmap="YlOrRd")
ax.set_xticks(range(12))
ax.set_xticklabels(meses_label)
ax.set_yticks(range(len(heatmap_data.index)))
ax.set_yticklabels(heatmap_data.index)
ax.set_title("Figura 4. Notificações de phishing por mês e ano (heatmap)", loc="left")
# Anotar valores
for i in range(heatmap_data.shape[0]):
    for j in range(heatmap_data.shape[1]):
        v = heatmap_data.values[i, j]
        if not np.isnan(v):
            ax.text(j, i, f"{int(v):,}".replace(",", "."), ha="center", va="center",
                    fontsize=7.5, color="black" if v < heatmap_data.values.max()*0.6 else "white")
cbar = plt.colorbar(im, ax=ax, fraction=0.025, pad=0.02)
cbar.set_label("Notificações")
plt.tight_layout()
plt.savefig(FIG / "fig4_heatmap.png", dpi=300, bbox_inches="tight")
plt.savefig(FIG / "fig4_heatmap.pdf", bbox_inches="tight")
plt.close()
print("  fig4_heatmap.png/pdf")

# Figura 5: Composição (phishing vs malware na fraude, share no total)
fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
# Anual: phishing vs malware
ax = axes[0]
ax.bar(desc_anual.index, desc_anual["phishing_total"]/1000, color="#1f3a5f",
       label="Phishing", edgecolor="black", linewidth=0.4)
ax.set_ylabel("Notificações (milhares)")
ax.set_title("(a) Notificações anuais de phishing", loc="left", fontsize=10.5)
ax.set_xlabel("Ano")

# Share
ax = axes[1]
ax.plot(desc_anual.index, desc_anual["share_phishing_%"], 
        color="#8B0000", marker="o", linewidth=1.7, markersize=6)
ax.set_ylabel("Phishing / Total de incidentes (%)")
ax.set_title("(b) Participação relativa do phishing", loc="left", fontsize=10.5)
ax.set_xlabel("Ano")
ax.set_ylim(0, max(desc_anual["share_phishing_%"]) * 1.15)
plt.tight_layout()
plt.savefig(FIG / "fig5_composicao.png", dpi=300, bbox_inches="tight")
plt.savefig(FIG / "fig5_composicao.pdf", bbox_inches="tight")
plt.close()
print("  fig5_composicao.png/pdf")

print("\nAnálise completa.")
